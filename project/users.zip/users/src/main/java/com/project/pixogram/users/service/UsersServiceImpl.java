package com.project.pixogram.users.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.pixogram.users.entity.Authorities;
import com.project.pixogram.users.entity.Users;
import com.project.pixogram.users.model.RegisterModel;
import com.project.pixogram.users.model.UsersModel;
import com.project.pixogram.users.repository.AuthorityRepository;
import com.project.pixogram.users.repository.UsersRepository;

@Service
public class UsersServiceImpl implements IUsersService{

	@Autowired
	private UsersRepository usersRepository;
	
	@Autowired
	private AuthorityRepository authorityRepository;

	@Override
	public List<Users> findAllUsers() {
		// TODO Auto-generated method stub
		return this.usersRepository.findAll();
	}

	@Override
	public Users findUsersById(Integer id) {
		// TODO Auto-generated method stub
		Optional<Users> record =  this.usersRepository.findById(id);
		Users users = new Users();
		if(record.isPresent())
		users = record.get();
		return users;
	}

	@Override
	public boolean addUsers(Users users) {
		// TODO Auto-generated method stub
		 this.usersRepository.save(users);
		 return true;
		
	}

	@Override
	public boolean updateUsers(Users users) {
		// TODO Auto-generated method stub
		 this.usersRepository.save(users);
		 return true;
	}

	@Override
	public boolean deleteUsers(Integer id) {
		// TODO Auto-generated method stub
		this.usersRepository.deleteById(id);
		return true;
	}

	@Override
	public void saveuser(UsersModel usersModel) {
		// TODO Auto-generated method stub
		Users data = new Users();
		
		data.setUsername(usersModel.getUsername());
		data.setFirstName(usersModel.getFirstName());
		data.setLastName(usersModel.getLastName());
		data.setEmail(usersModel.getEmail());
		data.setPassword("{noop}" + usersModel.getPassword());
	//	data.setProfilePic(usersModel.getProfilePic());
		data.setEnabled(true);
		this.usersRepository.save(data);
	
		
		// add authority
		Authorities authorities = new Authorities(usersModel.getUsername(), "ROLE_USER");
		this.authorityRepository.save(authorities);
	}	
	
	public void updateuser(RegisterModel user) {
		Users data = new Users();
		//Authorities auth = new Authorities();
		//auth.setUsername(user.getUsername());
		//auth.setAuthority("ROLE_USER");
		data.setId(user.getId());
		data.setUsername(user.getUsername());
		data.setFirstName(user.getFirstName());
		data.setLastName(user.getLastName());
		data.setEmail(user.getEmail());
		data.setDob(user.getDob());
		data.setPassword(user.getPassword());
		//data.setProfilepic(user.getProfilepic());
		data.setEnabled(true);
		this.usersRepository.save(data);
		}
	
	
	
	}




	
	


