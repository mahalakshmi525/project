package com.project.pixogram.users.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.pixogram.users.entity.Authorities;
import com.project.pixogram.users.repository.AuthorityRepository;

@Service
public class AuthorityService {

	@Autowired
	private AuthorityRepository authorityRepository;
	
	public void  saveauthority(Authorities authorities)
	{
		this.authorityRepository.save(authorities);
	}
}
