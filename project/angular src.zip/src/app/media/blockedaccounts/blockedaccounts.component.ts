import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blockedaccounts',
  templateUrl: './blockedaccounts.component.html',
  //styleUrls: ['./blockedaccounts.component.css']
})
export class BlockedaccountsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
